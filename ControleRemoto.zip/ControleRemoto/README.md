# Controle Remoto (Roku + Google TV / Android TV)

## Como gerar o APK
1. Instale o Android Studio e abra a pasta `ControleRemoto`.
2. Aguarde o Gradle sincronizar (precisa de internet).
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. O arquivo fica em `app/build/outputs/apk/debug/app-debug.apk`.
5. Copie para o celular e instale (permita "fontes desconhecidas").

## Como usar
- Celular e TV na mesma rede Wi-Fi.
- O app lista as TVs sozinho. Se a sua não aparecer, use "Adicionar por IP".
- Roku: conecta direto. Google TV: digite o código que aparece na TV (só na primeira vez).
- Na TV Roku, confira em Configurações > Sistema > Configurações avançadas > Controle por apps móveis: "Padrão" ou "Permissivo".
