package com.example.controleremoto

enum class TvType { ROKU, ANDROID_TV }

data class TvDevice(val name: String, val host: String, val type: TvType)

enum class RemoteKey(val roku: String, val android: Int) {
    UP("Up", 19), DOWN("Down", 20), LEFT("Left", 21), RIGHT("Right", 22),
    OK("Select", 23), BACK("Back", 4), HOME("Home", 3), MENU("Info", 82),
    VOL_UP("VolumeUp", 24), VOL_DOWN("VolumeDown", 25), MUTE("VolumeMute", 164),
    POWER("Power", 26), CH_UP("ChannelUp", 166), CH_DOWN("ChannelDown", 167),
    PLAY("Play", 85)
}

interface TvController {
    fun connect()
    fun send(key: RemoteKey)
    fun close()
}
