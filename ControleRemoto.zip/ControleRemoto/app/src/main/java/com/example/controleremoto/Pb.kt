package com.example.controleremoto

import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.InputStream
import java.io.OutputStream

/** Mini codificador/decodificador de protobuf, só o necessário para o protocolo Android TV. */
object Pb {
    fun varint(v0: Long): ByteArray {
        var v = v0
        val o = ByteArrayOutputStream()
        while ((v and 0x7FL.inv()) != 0L) {
            o.write(((v and 0x7F) or 0x80).toInt())
            v = v ushr 7
        }
        o.write(v.toInt())
        return o.toByteArray()
    }

    fun int(num: Int, v: Long) = varint((num shl 3).toLong()) + varint(v)
    fun bytes(num: Int, b: ByteArray) = varint(((num shl 3) or 2).toLong()) + varint(b.size.toLong()) + b
    fun str(num: Int, s: String) = bytes(num, s.toByteArray())
    fun cat(vararg parts: ByteArray): ByteArray = parts.reduce { a, b -> a + b }

    /** Campos varint viram Long, campos length-delimited viram ByteArray. */
    fun parse(b: ByteArray): Map<Int, Any> {
        val m = HashMap<Int, Any>()
        var i = 0
        fun readVar(): Long {
            var r = 0L; var s = 0
            while (true) {
                val x = b[i++].toInt() and 0xFF
                r = r or ((x and 0x7F).toLong() shl s)
                if (x and 0x80 == 0) return r
                s += 7
            }
        }
        while (i < b.size) {
            val tag = readVar()
            val num = (tag shr 3).toInt()
            when ((tag and 7).toInt()) {
                0 -> m[num] = readVar()
                2 -> { val len = readVar().toInt(); m[num] = b.copyOfRange(i, i + len); i += len }
                1 -> i += 8
                5 -> i += 4
                else -> return m
            }
        }
        return m
    }

    fun writeFrame(out: OutputStream, msg: ByteArray) {
        out.write(varint(msg.size.toLong()) + msg)
        out.flush()
    }

    fun readFrame(inp: InputStream): ByteArray {
        var len = 0L; var s = 0
        while (true) {
            val x = inp.read()
            if (x < 0) error("Conexão encerrada pela TV")
            len = len or ((x and 0x7F).toLong() shl s)
            if (x and 0x80 == 0) break
            s += 7
        }
        val buf = ByteArray(len.toInt())
        DataInputStream(inp).readFully(buf)
        return buf
    }
}
