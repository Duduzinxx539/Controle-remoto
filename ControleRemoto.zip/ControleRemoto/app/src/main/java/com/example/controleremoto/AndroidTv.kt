package com.example.controleremoto

import java.io.DataInputStream
import java.io.OutputStream
import java.math.BigInteger
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import javax.net.ssl.SSLSocket

/** Pareamento por PIN (porta 6467). */
class AndroidTvPairing(private val host: String, private val ks: KeyStore) {
    private lateinit var sock: SSLSocket
    private lateinit var inp: DataInputStream
    private lateinit var out: OutputStream

    private fun send(field: Int, body: ByteArray) =
        Pb.writeFrame(out, Pb.cat(Pb.int(1, 2), Pb.int(2, 200), Pb.bytes(field, body)))

    private fun expect(field: Int) {
        val m = Pb.parse(Pb.readFrame(inp))
        if (m[2] != 200L) error("A TV recusou o pareamento (status ${m[2]})")
        if (!m.containsKey(field)) error("Resposta inesperada da TV")
    }

    /** Faz a negociação inicial. Depois disso a TV mostra o código na tela. */
    fun start() {
        sock = Tls.connect(host, 6467, ks)
        inp = DataInputStream(sock.inputStream)
        out = sock.outputStream
        send(10, Pb.cat(Pb.str(1, "atvremote"), Pb.str(2, "Controle Remoto")))
        expect(11)
        val enc = Pb.cat(Pb.int(1, 3), Pb.int(2, 6)) // HEXADECIMAL, 6 símbolos
        send(20, Pb.cat(Pb.bytes(1, enc), Pb.int(3, 1)))
        expect(20)
        send(30, Pb.cat(Pb.bytes(1, enc), Pb.int(2, 1)))
        expect(31)
    }

    fun finish(code: String) {
        val pin = code.trim().uppercase()
        require(pin.length == 6 && pin.all { it in "0123456789ABCDEF" }) { "O código tem 6 caracteres" }
        val pinBytes = ByteArray(3) { pin.substring(it * 2, it * 2 + 2).toInt(16).toByte() }

        val clientKey = (ks.getCertificate("client") as X509Certificate).publicKey as RSAPublicKey
        val serverKey = (sock.session.peerCertificates[0] as X509Certificate).publicKey as RSAPublicKey

        fun big(n: BigInteger): ByteArray {
            val b = n.toByteArray()
            return if (b.size > 1 && b[0] == 0.toByte()) b.copyOfRange(1, b.size) else b
        }
        val md = MessageDigest.getInstance("SHA-256")
        md.update(big(clientKey.modulus)); md.update(big(clientKey.publicExponent))
        md.update(big(serverKey.modulus)); md.update(big(serverKey.publicExponent))
        md.update(pinBytes.copyOfRange(1, 3))
        val digest = md.digest()
        if (digest[0] != pinBytes[0]) error("Código incorreto")

        send(40, Pb.bytes(1, digest))
        expect(41)
        sock.close()
    }

    fun cancel() = try { sock.close() } catch (_: Exception) {}
}

/** Controle (porta 6466). */
class AndroidTvController(private val host: String, private val ks: KeyStore) : TvController {
    private var sock: SSLSocket? = null
    private var out: OutputStream? = null
    private val lock = Any()

    private fun write(msg: ByteArray) = synchronized(lock) { Pb.writeFrame(out!!, msg) }

    override fun connect() {
        val s = Tls.connect(host, 6466, ks)
        sock = s
        out = s.outputStream
        val inp = DataInputStream(s.inputStream)

        // Handshake: a TV manda configure, nós respondemos; depois set_active.
        while (true) {
            val m = Pb.parse(Pb.readFrame(inp))
            if (m.containsKey(1)) {
                val device = Pb.cat(
                    Pb.str(1, "Android"), Pb.str(2, "Google"), Pb.int(3, 1),
                    Pb.str(4, "1"), Pb.str(5, "com.example.controleremoto"), Pb.str(6, "1.0")
                )
                write(Pb.bytes(1, Pb.cat(Pb.int(1, 622), Pb.bytes(2, device))))
            }
            if (m.containsKey(2)) {
                write(Pb.bytes(2, Pb.int(1, 622)))
                break
            }
            if (m.containsKey(8)) pong(m[8] as ByteArray)
        }
        s.soTimeout = 0

        // Thread que só responde aos pings, para a TV não derrubar a conexão.
        Thread {
            try {
                while (true) {
                    val m = Pb.parse(Pb.readFrame(inp))
                    if (m.containsKey(8)) pong(m[8] as ByteArray)
                }
            } catch (_: Exception) {}
        }.apply { isDaemon = true }.start()
    }

    private fun pong(ping: ByteArray) {
        val v = Pb.parse(ping)[1] as? Long ?: 0L
        write(Pb.bytes(9, Pb.int(1, v)))
    }

    override fun send(key: RemoteKey) {
        // direction 3 = toque curto
        write(Pb.bytes(10, Pb.cat(Pb.int(1, key.android.toLong()), Pb.int(2, 3))))
    }

    override fun close() = try { sock?.close() } catch (_: Exception) {}
}
