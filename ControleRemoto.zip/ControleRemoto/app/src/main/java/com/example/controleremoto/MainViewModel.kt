package com.example.controleremoto

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.security.KeyStore

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    val devices = mutableStateListOf<TvDevice>()
    var status by mutableStateOf("")
    var connected by mutableStateOf(false)
    var needPin by mutableStateOf(false)
    var current by mutableStateOf<TvDevice?>(null)

    private val prefs = app.getSharedPreferences("tv", 0)
    private var discovery: Discovery? = null
    private var controller: TvController? = null
    private var pairing: AndroidTvPairing? = null

    fun startDiscovery() {
        discovery?.stop()
        status = "Procurando TVs na rede Wi-Fi..."
        discovery = Discovery(app) { d ->
            viewModelScope.launch(Dispatchers.Main) {
                if (devices.none { it.host == d.host }) devices.add(d)
            }
        }.also { it.start() }
    }

    fun addManual(host: String, type: TvType) {
        val h = host.trim()
        if (h.isNotEmpty() && devices.none { it.host == h }) {
            devices.add(TvDevice(if (type == TvType.ROKU) "TV Roku ($h)" else "Google TV ($h)", h, type))
        }
    }

    fun select(d: TvDevice) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                current = d
                status = "Conectando a ${d.name}..."
                when (d.type) {
                    TvType.ROKU -> {
                        val c = RokuController(d.host); c.connect()
                        controller = c; connected = true; status = ""
                    }
                    TvType.ANDROID_TV -> {
                        val ks = Tls.keyStore(app)
                        if (!prefs.getBoolean("paired_${d.host}", false)) {
                            pairing = AndroidTvPairing(d.host, ks).also { it.start() }
                            needPin = true
                            status = "Digite o código que apareceu na TV"
                        } else connectAtv(d, ks)
                    }
                }
            } catch (e: Exception) {
                status = "Falha: ${e.message}"
            }
        }
    }

    fun submitPin(code: String) {
        val d = current ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                pairing?.finish(code)
                prefs.edit().putBoolean("paired_${d.host}", true).apply()
                needPin = false
                connectAtv(d, Tls.keyStore(app))
            } catch (e: Exception) {
                status = "Falha: ${e.message}"
                needPin = false
                pairing?.cancel()
            }
        }
    }

    fun cancelPin() { needPin = false; pairing?.cancel(); status = "" }

    private fun connectAtv(d: TvDevice, ks: KeyStore) {
        try {
            val c = AndroidTvController(d.host, ks); c.connect()
            controller = c; connected = true; status = ""
        } catch (e: Exception) {
            prefs.edit().remove("paired_${d.host}").apply() // força novo pareamento
            status = "Não conectou (${e.message}). Toque na TV de novo para parear."
        }
    }

    fun press(key: RemoteKey) {
        viewModelScope.launch(Dispatchers.IO) {
            try { controller?.send(key) }
            catch (e: Exception) { status = "Conexão perdida"; connected = false }
        }
    }

    fun disconnect() {
        controller?.close(); controller = null; connected = false; status = ""
    }

    override fun onCleared() { discovery?.stop(); controller?.close() }
}
