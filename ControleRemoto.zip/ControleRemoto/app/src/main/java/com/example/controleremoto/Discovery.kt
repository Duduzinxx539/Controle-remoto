package com.example.controleremoto

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import kotlin.concurrent.thread

class Discovery(private val ctx: Context, private val onFound: (TvDevice) -> Unit) {
    private val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private var mcLock: WifiManager.MulticastLock? = null
    private var listener: NsdManager.DiscoveryListener? = null
    private val queue = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    fun start() {
        startSsdp()
        startNsd()
    }

    fun stop() {
        try { listener?.let { nsd.stopServiceDiscovery(it) } } catch (_: Exception) {}
        listener = null
        try { mcLock?.release() } catch (_: Exception) {}
    }

    // Roku responde a busca SSDP "roku:ecp"
    private fun startSsdp() = thread(isDaemon = true) {
        try {
            val wifi = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            mcLock = wifi.createMulticastLock("controleremoto").apply { setReferenceCounted(false); acquire() }
            val msg = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n" +
                "MAN: \"ssdp:discover\"\r\nMX: 2\r\nST: roku:ecp\r\n\r\n").toByteArray()
            val seen = HashSet<String>()
            DatagramSocket().use { s ->
                s.soTimeout = 2000
                repeat(3) {
                    s.send(DatagramPacket(msg, msg.size, InetAddress.getByName("239.255.255.250"), 1900))
                    try {
                        while (true) {
                            val buf = ByteArray(2048)
                            val p = DatagramPacket(buf, buf.size)
                            s.receive(p)
                            val text = String(p.data, 0, p.length)
                            val host = Regex("(?i)location:\\s*http://([^:/\\s]+)").find(text)?.groupValues?.get(1)
                            if (host != null && seen.add(host)) {
                                onFound(TvDevice(RokuController.deviceName(host), host, TvType.ROKU))
                            }
                        }
                    } catch (_: SocketTimeoutException) {}
                }
            }
        } catch (_: Exception) {}
    }

    // Android TV / Google TV se anuncia via mDNS
    private fun startNsd() {
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onServiceLost(i: NsdServiceInfo) {}
            override fun onServiceFound(i: NsdServiceInfo) {
                synchronized(queue) { queue.addLast(i) }
                resolveNext()
            }
        }
        listener = l
        try { nsd.discoverServices("_androidtvremote2._tcp.", NsdManager.PROTOCOL_DNS_SD, l) } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    private fun resolveNext() {
        val next = synchronized(queue) {
            if (resolving || queue.isEmpty()) return
            resolving = true
            queue.removeFirst()
        }
        nsd.resolveService(next, object : NsdManager.ResolveListener {
            override fun onResolveFailed(i: NsdServiceInfo, e: Int) { done() }
            override fun onServiceResolved(i: NsdServiceInfo) {
                i.host?.hostAddress?.let { onFound(TvDevice(i.serviceName, it, TvType.ANDROID_TV)) }
                done()
            }
            private fun done() { synchronized(queue) { resolving = false }; resolveNext() }
        })
    }
}
