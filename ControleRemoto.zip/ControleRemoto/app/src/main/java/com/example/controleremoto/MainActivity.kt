package com.example.controleremoto

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize()) { App() }
            }
        }
    }
}

@Composable
fun App(vm: MainViewModel = viewModel()) {
    LaunchedEffect(Unit) { vm.startDiscovery() }
    if (vm.connected) RemoteScreen(vm) else DeviceScreen(vm)
    if (vm.needPin) PinDialog(vm)
}

@Composable
fun DeviceScreen(vm: MainViewModel) {
    var showManual by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp)) {
        Text("Controle Remoto", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(4.dp))
        Text(vm.status, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(16.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.devices) { d ->
                Card(Modifier.fillMaxWidth().clickable { vm.select(d) }) {
                    Column(Modifier.padding(16.dp)) {
                        Text(d.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            "${if (d.type == TvType.ROKU) "Roku" else "Google TV / Android TV"} · ${d.host}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.startDiscovery() }) { Text("Buscar de novo") }
            OutlinedButton(onClick = { showManual = true }) { Text("Adicionar por IP") }
        }
    }
    if (showManual) ManualDialog(onDismiss = { showManual = false }) { ip, t -> vm.addManual(ip, t); showManual = false }
}

@Composable
fun ManualDialog(onDismiss: () -> Unit, onAdd: (String, TvType) -> Unit) {
    var ip by remember { mutableStateOf("") }
    var type by remember { mutableStateOf(TvType.ROKU) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Adicionar TV") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(ip, { ip = it }, label = { Text("IP da TV (ex.: 192.168.0.20)") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(type == TvType.ROKU, { type = TvType.ROKU }, label = { Text("Roku") })
                    FilterChip(type == TvType.ANDROID_TV, { type = TvType.ANDROID_TV }, label = { Text("Google TV") })
                }
            }
        },
        confirmButton = { TextButton(onClick = { onAdd(ip, type) }) { Text("Adicionar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
fun PinDialog(vm: MainViewModel) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = { vm.cancelPin() },
        title = { Text("Parear com a TV") },
        text = {
            Column {
                Text("Digite o código de 6 caracteres que está na tela da TV.")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(pin, { pin = it.take(6).uppercase() }, singleLine = true, label = { Text("Código") })
            }
        },
        confirmButton = { TextButton(onClick = { vm.submitPin(pin) }) { Text("Parear") } },
        dismissButton = { TextButton(onClick = { vm.cancelPin() }) { Text("Cancelar") } }
    )
}

@Composable
fun RemoteScreen(vm: MainViewModel) {
    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(vm.current?.name ?: "", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { vm.disconnect() }) { Text("Trocar TV") }
        }
        Button(onClick = { vm.press(RemoteKey.POWER) }, colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)) { Text("⏻  Ligar/Desligar") }

        Spacer(Modifier.height(4.dp))
        Key("▲", RemoteKey.UP, vm)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Key("◀", RemoteKey.LEFT, vm); Key("OK", RemoteKey.OK, vm); Key("▶", RemoteKey.RIGHT, vm)
        }
        Key("▼", RemoteKey.DOWN, vm)

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Key("Voltar", RemoteKey.BACK, vm); Key("Home", RemoteKey.HOME, vm); Key("Menu", RemoteKey.MENU, vm)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(30.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Volume"); Key("+", RemoteKey.VOL_UP, vm); Key("🔇", RemoteKey.MUTE, vm); Key("−", RemoteKey.VOL_DOWN, vm)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Canal"); Key("+", RemoteKey.CH_UP, vm); Key("⏯", RemoteKey.PLAY, vm); Key("−", RemoteKey.CH_DOWN, vm)
            }
        }
        if (vm.status.isNotEmpty()) Text(vm.status, color = MaterialTheme.colorScheme.error)
    }
}

@Composable
fun Key(label: String, key: RemoteKey, vm: MainViewModel) {
    FilledTonalButton(onClick = { vm.press(key) }, modifier = Modifier.widthIn(min = 76.dp).height(56.dp)) { Text(label) }
}
