package com.example.controleremoto

import java.net.HttpURLConnection
import java.net.URL

class RokuController(private val host: String) : TvController {

    override fun connect() {
        // Só confirma que a TV responde na porta 8060
        val info = request("GET", "/query/device-info")
        if (info.isEmpty()) error("A TV não respondeu")
    }

    override fun send(key: RemoteKey) {
        request("POST", "/keypress/${key.roku}")
    }

    override fun close() {}

    private fun request(method: String, path: String): String {
        val c = URL("http://$host:8060$path").openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 3000
            c.readTimeout = 3000
            if (method == "POST") c.doOutput = true.also { c.outputStream.close() }
            if (c.responseCode !in 200..299) error("Erro HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().readText()
        } finally {
            c.disconnect()
        }
    }

    companion object {
        fun deviceName(host: String): String = try {
            val c = URL("http://$host:8060/query/device-info").openConnection() as HttpURLConnection
            c.connectTimeout = 2000; c.readTimeout = 2000
            val text = c.inputStream.bufferedReader().readText()
            Regex("<friendly-device-name>(.*?)</").find(text)?.groupValues?.get(1) ?: "TV Roku"
        } catch (e: Exception) { "TV Roku" }
    }
}
